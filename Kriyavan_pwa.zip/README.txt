Kriyavan PWA
=============

Files included:
- index.html
- manifest.json
- service-worker.js
- icons/icon-192.png
- icons/icon-512.png

How to publish (quick):
1) GitHub Pages:
   - Create a repository (public) and upload the contents of this folder.
   - In repo settings -> Pages, set branch to 'main' or 'gh-pages' and folder to '/'.
   - Visit the provided GitHub Pages URL.

2) Netlify (drag & drop):
   - Go to https://app.netlify.com/drop and drop the entire folder.
   - Netlify publishes a live URL immediately.
